@echo off
"%~dp0Start-One-Click.cmd"
